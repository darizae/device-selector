__version__ = "0.1.0"

from .device_selector import select_best_device, check_or_select_device
